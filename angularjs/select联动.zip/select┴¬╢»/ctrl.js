var allAreas = [{
			name:'北京市',
			code:'11',
			items:[{
				code:'110100',
				name:'市辖区',
				items:[{
					code:'110101',
					name:'东城区'
				},{
					code:'110102',
					name:'西城区'
				}]
			},{
					code:'110200',
					name:'县',
					items:[{
						code:'110228',
						name:'密云县'
					},{
						code:'110229',
						name:'延庆县'
					}]
			}]
		},{
			name:'北京市1',
			code:'11',
			items:[{
				code:'110100',
				name:'市辖区1',
				items:[{
					code:'110101',
					name:'东城区'
				},{
					code:'110102',
					name:'西城区'
				}]
			},{
					code:'110200',
					name:'县1',
					items:[{
						code:'110228',
						name:'密云县'
					},{
						code:'110229',
						name:'延庆县'
					}]
			}]
		}]


 function MyCntrl($scope) {
		$scope.areasArr = allAreas;
		$scope.areaItem = $scope.areasArr[0];
		
		$scope.$watch('areaItem', function(val){
			$scope.areaNext = val.items;
			$scope.areaNextItem = $scope.areaNext[0];
		});

		$scope.$watch('areaNextItem', function(val){
			$scope.gareaNext = val.items;
			$scope.gareaNextItem = $scope.gareaNext[0];
		});
  }
